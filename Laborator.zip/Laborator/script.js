document.addEventListener('DOMContentLoaded', function() {
   
    const supportHeaders = document.querySelectorAll('.support-header');
    
   
    supportHeaders.forEach(header => {
        header.addEventListener('click', function() {
           
            this.classList.toggle('active');
            
            
            const content = this.nextElementSibling;
            
           
            if (content.style.display === 'block') {
                content.style.display = 'none';
            }
           
            else {
               
                document.querySelectorAll('.support-content').forEach(content => {
                    content.style.display = 'none';
                });
                
                
                document.querySelectorAll('.support-header').forEach(header => {
                    header.classList.remove('active');
                });
                
                content.style.display = 'block';
                this.classList.add('active');
            }
        });
    });
});