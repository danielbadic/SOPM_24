document.getElementById('offerButton').addEventListener('click', function() {
    const offerSection = document.getElementById('offerSection');
    offerSection.classList.toggle('hidden');
});